﻿
document.addEventListener("DOMContentLoaded", function () {
    const langMap = { hi: "हिंदी", en: "English" };
    const loaderTextMap = {
        hi: "भाषा बदली जा रही है...",
        en: "Switching language..."
    };

    const languageSwitcher = document.getElementById("languageSwitcher");
    const currentLangSpan = document.getElementById("currentLang");
    const altLangBox = document.getElementById("altLangBox");
    const langLoader = document.getElementById("langLoader");
    const langLoaderText = document.getElementById("langLoaderText");

    if (!languageSwitcher || !currentLangSpan || !altLangBox) return;

    const serverLang = languageSwitcher.getAttribute("data-server-lang") || "en";
    const setLangBaseUrl = languageSwitcher.getAttribute("data-lang-url") || "/Language/SetLanguage";

    //function updateLanguageUI(lang) {
    //    const altLang = lang === "hi" ? "en" : "hi";

    //    currentLangSpan.innerHTML = `
    //<span class="language-link" data-lang="${lang}" style="cursor:pointer;">
    //    ${langMap[lang]}
    //</span>`;

    //    altLangBox.innerHTML = `
    //<a href="#" class="language-link" id="langSwitchLink" style="display:block; padding:4px;" data-lang="${altLang}">
    //    ${langMap[altLang]}
    //</a>`;
    //}

    function updateLanguageUI(lang) {
        const altLang = lang === "hi" ? "en" : "hi";

        currentLangSpan.innerHTML = `
    <span id="langSwitchLink" class="language-link" data-lang="${altLang}" style="cursor:pointer; font-weight:bold;">
        ${langMap[altLang]}
    </span>`;

        altLangBox.style.display = "none"; // Always hidden, dropdown disabled
    }


    updateLanguageUI(serverLang);

    //currentLangSpan.addEventListener("click", function (e) {
    //    e.stopPropagation();
    //    altLangBox.style.display = altLangBox.style.display === "block" ? "none" : "block";
    //});

    //document.addEventListener("click", function (e) {
    //    if (!languageSwitcher.contains(e.target)) {
    //        altLangBox.style.display = "none";
    //    }
    //});

    // ✅ Show loader and set text on language change
    document.addEventListener("click", function (e) {
        const link = e.target.closest("#langSwitchLink");
        if (link) {
            e.preventDefault();
            const selectedLang = link.getAttribute("data-lang");

            if (langLoader) {
                if (langLoaderText) {
                    langLoaderText.textContent = loaderTextMap[selectedLang] || "Switching language...";
                }
                langLoader.style.display = "block";
            }

            setTimeout(() => {
                window.location.href = `${setLangBaseUrl}?lang=${selectedLang}`;
            }, 100);
        }
    });
});













