﻿function setLineSpacing(level) {
    document.body.classList.remove("line-normal", "line-wide");
    document.body.classList.add("line-" + level);
    localStorage.setItem("lineSpacing", level);
}

function toggleLineSpacing() {
    const body = document.body;
    const btn = document.getElementById("accessibilityToggleBtn");
    const isWide = body.classList.contains("line-wide");

    body.classList.remove("line-normal", "line-wide");
    body.classList.add(isWide ? "line-normal" : "line-wide");

    localStorage.setItem("lineSpacing", isWide ? "normal" : "wide");
    btn?.classList.toggle("active", !isWide);
}

// On DOM Ready - Load Saved Line Spacing and Bind Toggle Button
document.addEventListener("DOMContentLoaded", function () {
    if (localStorage.getItem("lineSpacing")) {
        setLineSpacing(localStorage.getItem("lineSpacing"));
    }

    document.getElementById("accessibilityToggleBtn")?.addEventListener("click", toggleLineSpacing);
});
