﻿// On DOM Ready - Load Saved Vertical Spacing
document.addEventListener("DOMContentLoaded", function () {
    if (localStorage.getItem("verticalSpacing")) {
        const level = localStorage.getItem("verticalSpacing");
        document.body.classList.add("vspace-" + level);
        if (level === "wide") {
            document.getElementById("accessibilityToggleBtn")?.classList.add("active");
        }
    }
});
