﻿const storedTheme = localStorage.getItem("selectedTheme") || "default";

function setTheme(theme) {
    document.body.classList.remove("theme-black", "theme-gray");
    if (theme === "black" || theme === "gray") {
        document.body.classList.add("theme-" + theme);
    }
    localStorage.setItem("selectedTheme", theme);
}

// On DOM Ready - Load Saved Theme
document.addEventListener("DOMContentLoaded", function () {
    setTheme(storedTheme);
});
