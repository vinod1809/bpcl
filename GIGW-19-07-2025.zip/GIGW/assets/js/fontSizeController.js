﻿//// Global Variables
//let currentFontPx = parseFloat(localStorage.getItem("fontSizePx")) || 14;

//const minFontPx = 10;
//const maxFontPx = 18;
//const stepPx = 2;

//// Apply font size in px to body
//function applyFontSizePx(value) {
//    document.body.style.fontSize = value + 'px';
//    localStorage.setItem("fontSizePx", value);
//}

//// Adjust Font Size Logic
//function adjustFontSize(action) {
//    if (action === 'increase' && currentFontPx < maxFontPx) {
//        currentFontPx = Math.min(currentFontPx + stepPx, maxFontPx);
//    } else if (action === 'decrease' && currentFontPx > minFontPx) {
//        currentFontPx = Math.max(currentFontPx - stepPx, minFontPx);
//    } else if (action === 'reset') {
//        currentFontPx = 14;
//    }
//    applyFontSizePx(currentFontPx);
//}

//// Global Function Called on Button Click
//function changeFontSize(value) {
//    if (value === 'small') {
//        adjustFontSize('decrease');
//    } else if (value === 'large') {
//        adjustFontSize('increase');
//    } else {
//        adjustFontSize('reset');
//    }
//}

//// Initialize on Page Load
//document.addEventListener("DOMContentLoaded", function () {
//    const fontIcon = document.querySelector("#fontSizeDropdown img");
//    const fontPopup = document.getElementById("fontSizePopup");

//    if (fontIcon && fontPopup) {
//        fontIcon.addEventListener("click", function (e) {
//            e.stopPropagation();
//            fontPopup.style.display = (fontPopup.style.display === "block") ? "none" : "block";
//            console.log("Font icon clicked. Popup is now:", fontPopup.style.display);
//        });

//        fontPopup.addEventListener("click", function (e) {
//            e.stopPropagation();
//            console.log("Clicked inside popup. Popup remains open.");
//        });

//        document.addEventListener("click", function () {
//            if (fontPopup.style.display === "block") {
//                fontPopup.style.display = "none";
//                console.log("Clicked outside. Popup hidden.");
//            }
//        });
//    } else {
//        console.log("Font icon or popup not found in DOM.");
//    }
//});



let currentFontPx = parseFloat(localStorage.getItem("fontSizePx")) || 14;

const minFontPx = 10;
const maxFontPx = 18;
const stepPx = 2;

// Apply font size on html (root element)
function applyFontSizePx(value) {
    document.documentElement.style.fontSize = value + 'px';
    localStorage.setItem("fontSizePx", value);
}

function adjustFontSize(action) {
    if (action === 'increase' && currentFontPx < maxFontPx) {
        currentFontPx = Math.min(currentFontPx + stepPx, maxFontPx);
    } else if (action === 'decrease' && currentFontPx > minFontPx) {
        currentFontPx = Math.max(currentFontPx - stepPx, minFontPx);
    } else if (action === 'reset') {
        currentFontPx = 14;
    }
    applyFontSizePx(currentFontPx);
}

function changeFontSize(value) {
    if (value === 'small') {
        adjustFontSize('decrease');
    } else if (value === 'large') {
        adjustFontSize('increase');
    } else {
        adjustFontSize('reset');
    }
}

document.addEventListener("DOMContentLoaded", function () {
    const fontIcon = document.querySelector("#fontSizeDropdown img");
    const fontPopup = document.getElementById("fontSizePopup");

    if (fontIcon && fontPopup) {
        fontIcon.addEventListener("click", function (e) {
            e.stopPropagation();
            fontPopup.style.display = (fontPopup.style.display === "block") ? "none" : "block";
            console.log("Font icon clicked. Popup is now:", fontPopup.style.display);
        });

        fontPopup.addEventListener("click", function (e) {
            e.stopPropagation();
        });

        document.addEventListener("click", function () {
            if (fontPopup.style.display === "block") {
                fontPopup.style.display = "none";
            }
        });
    } else {
        console.log("Font icon or popup not found in DOM.");
    }
    applyFontSizePx(currentFontPx);
});

