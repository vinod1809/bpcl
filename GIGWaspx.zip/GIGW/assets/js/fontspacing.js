﻿/* jshint esversion: 6 */
function setFontSpacing(level) {
    document.body.classList.remove("spacing-normal", "spacing-wide");
    document.body.classList.add("spacing-" + level);
    localStorage.setItem("fontSpacing", level);
}

// On DOM Ready - Load Saved Font Spacing
document.addEventListener("DOMContentLoaded", function () {
    if (localStorage.getItem("fontSpacing")) {
        setFontSpacing(localStorage.getItem("fontSpacing"));
    }
});

// Toggle Letter Spacing Button
function toggleLetterSpacing() {
    const isWide = document.body.classList.contains("spacing-wide");
    setFontSpacing(isWide ? "normal" : "wide");
}
