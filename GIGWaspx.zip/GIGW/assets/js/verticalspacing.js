﻿///* jshint esversion: 6 */

//// On DOM Ready - Load Saved Vertical Spacing
//document.addEventListener("DOMContentLoaded", function () {
//    if (localStorage.getItem("verticalSpacing")) {
//        const level = localStorage.getItem("verticalSpacing");
//        document.body.classList.add("vspace-" + level);
//        if (level === "wide") {
//            document.getElementById("accessibilityToggleBtn")?.classList.add("active");
//        }
//    }
//});


document.addEventListener("DOMContentLoaded", function () {
    // Apply saved vertical spacing on page load
    if (localStorage.getItem("verticalSpacing")) {
        const level = localStorage.getItem("verticalSpacing");
        document.body.classList.add("vspace-" + level);

        if (level === "wide") {
            document.getElementById("accessibilityToggleBtn")?.classList.add("active");
        }
    }

    // Toggle Vertical Spacing on Button Click
    document.getElementById("accessibilityToggleBtn")?.addEventListener("click", function (e) {
        e.preventDefault();

        if (document.body.classList.contains("vspace-wide")) {
            document.body.classList.remove("vspace-wide");
            document.body.classList.add("vspace-normal");
            localStorage.setItem("verticalSpacing", "normal");
            this.classList.remove("active");
        } else {
            document.body.classList.remove("vspace-normal");
            document.body.classList.add("vspace-wide");
            localStorage.setItem("verticalSpacing", "wide");
            this.classList.add("active");
        }
    });
});
