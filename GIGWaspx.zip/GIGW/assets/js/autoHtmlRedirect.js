﻿(function () {
    var lang = document.cookie.replace(/(?:(?:^|.*;\s*)lang\s*=\s*([^;]*).*$)|^.*$/, "$1") || 'en';
    if (lang === 'hi') {
        var path = window.location.pathname;
        var parts = path.split('/');
        var fileName = parts.pop();
        var folder = parts.join('/');
        var hiPath = folder + '/hi/' + fileName;

        if (!/\/hi\//.test(path)) {
            fetch(hiPath, { method: 'HEAD' }).then(function (response) {
                if (response.status === 200) {
                    window.location.href = hiPath;
                } else {
                    window.location.href = '/Pages/HindiNotAvailable.aspx?returnUrl=' + encodeURIComponent(path);
                }
            }).catch(function () {
                window.location.href = '/Pages/HindiNotAvailable.aspx?returnUrl=' + encodeURIComponent(path);
            });
        }
    }
})();
