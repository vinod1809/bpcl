﻿/* jshint esversion: 6 */

function setLineSpacing(level) {
    document.body.classList.remove("line-normal", "line-wide");
    document.body.classList.add("line-" + level);
    localStorage.setItem("lineSpacing", level);
    console.log(`✅ Line spacing set to: ${level}`);
}

function toggleLineSpacing() {
    const body = document.body;
    const isWide = body.classList.contains("line-wide");

    body.classList.remove("line-normal", "line-wide");
    body.classList.add(isWide ? "line-normal" : "line-wide");

    localStorage.setItem("lineSpacing", isWide ? "normal" : "wide");

    if (document.getElementById("accessibilityToggleBtn")) {
        document.getElementById("accessibilityToggleBtn").classList.toggle("active", !isWide);
    }

    console.log(`📝 Line spacing toggled. Now: ${isWide ? "Normal" : "Wide"}`);
}

// On DOM Ready - Load Saved Line Spacing
$(document).ready(function () {
    if (localStorage.getItem("lineSpacing")) {
        setLineSpacing(localStorage.getItem("lineSpacing"));
    }

    // Delegate Click for Dynamically Loaded Toolbar Button
    $(document).on('click', '#accessibilityToggleBtn', function (e) {
        e.preventDefault();
        console.log("🔘 Line Spacing Toggle Button Clicked");
        toggleLineSpacing();
    });
});
