﻿//function initializeFooterSlider() {
//    console.log('✅ initializeFooterSlider() called');

//    var $wrapper = $('#multiSliderWrapper');
//    var $dotsContainer = $('#multiSliderDots');

//    if ($wrapper.length === 0) {
//        console.error('❌ multiSliderWrapper not found after footer loaded!');
//        return;
//    }

//    var currentIndex = 0;
//    var visibleSlides = 4;
//    var slideWidth = 0;
//    var autoPlay = true;
//    var interval;

//    $.getJSON('/GIGW/assets/urlfile.json', function (data) {
//        if (!data || data.length === 0) {
//            console.warn('⚠️ No data in urlfile.json — rendering blank slider');
//            $wrapper.html('<div>No images found!</div>');
//            return;
//        }

//        $wrapper.empty();
//        $dotsContainer.empty();

//        data.forEach(function (item, index) {
//            var imgPath = `/GIGW/assets/fslider/${item.image}`;
//            var imgElement = `<img src="${imgPath}" class="multi-slide" alt="Slider Image" />`;

//            var slideHTML = item.url
//                ? `<div class="multi-slide-wrapper"><a href="${item.url}" target="_blank">${imgElement}</a></div>`
//                : `<div class="multi-slide-wrapper">${imgElement}</div>`;

//            $wrapper.append(slideHTML);

//            var dot = `<span class="dot" data-index="${index}"></span>`;
//            $dotsContainer.append(dot);

//            var imgTest = new Image();
//            imgTest.onload = function () {
//                console.log(`✅ Image loaded: ${imgPath}`);
//            };
//            imgTest.onerror = function () {
//                console.error(`❌ Failed to load image: ${imgPath}`);
//            };
//            imgTest.src = imgPath;
//        });

//        calculateSlideWidth();
//        updateDots();
//        updateArrows();
//        startAutoPlay();

//        $('.dot').on('click', function () {
//            var index = parseInt($(this).attr('data-index'));
//            if (index <= maxIndex) {
//                currentIndex = index;
//            } else {
//                currentIndex = maxIndex;
//            }
//            updateSliderPosition();
//            updateDots();
//            updateArrows();
//        });

//    }).fail(function () {
//        console.error('❌ Failed to load urlfile.json — rendering empty slider');
//        $wrapper.html('<div>Slider data not available!</div>');
//    });

//    function calculateSlideWidth() {
//        slideWidth = $('.multi-slide-wrapper').outerWidth(true);

//        var windowWidth = $(window).width();
//        if (windowWidth <= 480) {
//            visibleSlides = 1;
//        } else if (windowWidth <= 768) {
//            visibleSlides = 2;
//        } else if (windowWidth <= 1024) {
//            visibleSlides = 3;
//        } else {
//            visibleSlides = 4;
//        }

//        $wrapper.css('width', $('.multi-slide-wrapper').length * slideWidth + 'px');
//        updateSliderPosition();
//        updateArrows();
//    }

//    function moveLeft() {
//        if (currentIndex > 0) {
//            currentIndex--;
//            updateSliderPosition();
//            updateDots();
//            updateArrows();
//        }
//    }

//    function moveRight() {
//        var totalSlides = $('.multi-slide-wrapper').length;
//        var maxIndex = totalSlides - 1;
//        if (currentIndex < maxIndex) {
//            currentIndex++;
//            updateSliderPosition();
//            updateDots();
//            updateArrows();
//        }
//    }


//    function updateSliderPosition() {
//        $wrapper.css('transform', `translateX(-${currentIndex * slideWidth}px)`);
//    }


//    function updateDots() {
//        $('.dot').removeClass('active');
//        $(`.dot[data-index="${currentIndex}"]`).addClass('active');
//    }

//    function updateArrows() {
//        var totalSlides = $('.multi-slide-wrapper').length;
//        var maxIndex = totalSlides - 1;

//        $('.arrow.left').prop('disabled', currentIndex === 0);
//        $('.arrow.right').prop('disabled', currentIndex >= maxIndex);
//    }



//    function startAutoPlay() {
//        clearInterval(interval);
//        if (autoPlay) {
//            interval = setInterval(function () {
//                var totalSlides = $('.multi-slide-wrapper').length;
//                var maxIndex = totalSlides - visibleSlides;

//                if (currentIndex < maxIndex) {
//                    currentIndex++;
//                } else {
//                    currentIndex = 0;
//                }
//                updateSliderPosition();
//                updateDots();
//                updateArrows();
//            }, 3000);
//        }
//    }

//    window.moveLeft = moveLeft;
//    window.moveRight = moveRight;
//    window.toggleMultiPlayPause = function () {
//        autoPlay = !autoPlay;
//        if (autoPlay) {
//            startAutoPlay();
//            $('#multiPlayPauseBtn').text('⏸️');
//        } else {
//            clearInterval(interval);
//            $('#multiPlayPauseBtn').text('▶️');
//        }
//    };

//    $(window).on('resize', calculateSlideWidth);
//}




function initializeFooterSlider() {
    console.log('✅ initializeFooterSlider() called');

    var $wrapper = $('#multiSliderWrapper');
    var $dotsContainer = $('#multiSliderDots');

    if ($wrapper.length === 0) {
        console.error('❌ multiSliderWrapper not found after footer loaded!');
        return;
    }

    var currentIndex = 0;
    var slideWidth = 0;
    var autoPlay = true;
    var interval;

    $.getJSON('/GIGW/assets/urlfile.json', function (data) {
        if (!data || data.length === 0) {
            console.warn('⚠️ No data in urlfile.json — rendering blank slider');
            $wrapper.html('<div>No images found!</div>');
            return;
        }

        $wrapper.empty();
        $dotsContainer.empty();

        data.forEach(function (item, index) {
            var imgPath = `/GIGW/assets/fslider/${item.image}`;
            var slideHTML = `<div class="multi-slide-wrapper">
                                <a href="${item.url}" target="_blank">
                                    <img src="${imgPath}" class="multi-slide" alt="Slider Image" />
                                </a>
                            </div>`;
            $wrapper.append(slideHTML);
            $dotsContainer.append(`<span class="dot" data-index="${index}"></span>`);
        });

        calculateSlideWidth();
        updateArrows();
        updateDots();
        startAutoPlay();

        $('.dot').on('click', function () {
            currentIndex = parseInt($(this).attr('data-index'));
            updateSliderPosition();
            updateArrows();
            updateDots();
        });
    }).fail(function () {
        console.error('❌ Failed to load urlfile.json — rendering empty slider');
        $wrapper.html('<div>Slider data not available!</div>');
    });

    function calculateSlideWidth() {
        var windowWidth = $(window).width();
        var visibleSlides = (windowWidth <= 480) ? 1 :
            (windowWidth <= 768) ? 2 :
                (windowWidth <= 1024) ? 3 : 4;

        var containerWidth = $wrapper.parent().width();
        slideWidth = containerWidth / visibleSlides;
        $('.multi-slide-wrapper').css('width', slideWidth + 'px');

        var totalWidth = $('.multi-slide-wrapper').length * slideWidth;
        $wrapper.css('width', totalWidth + 'px');

        updateSliderPosition();
        updateArrows();
        updateDots();
    }

    function moveLeft() {
        if (currentIndex > 0) {
            currentIndex--;
            updateSliderPosition();
            updateArrows();
            updateDots();
        }
    }

    function moveRight() {
        var totalSlides = $('.multi-slide-wrapper').length;
        if (currentIndex < totalSlides - 1) {
            currentIndex++;
            updateSliderPosition();
            updateArrows();
            updateDots();
        }
    }

    function updateSliderPosition() {
        $wrapper.css('transform', `translateX(-${currentIndex * slideWidth}px)`);
    }

    function updateArrows() {
        var totalSlides = $('.multi-slide-wrapper').length;
        $('.arrow.left').prop('disabled', currentIndex === 0);
        $('.arrow.right').prop('disabled', currentIndex >= totalSlides - 1);
    }

    function updateDots() {
        $('.dot').removeClass('active');
        $(`.dot[data-index="${currentIndex}"]`).addClass('active');
    }

    function startAutoPlay() {
        clearInterval(interval);
        if (autoPlay) {
            interval = setInterval(function () {
                var totalSlides = $('.multi-slide-wrapper').length;
                if (currentIndex < totalSlides - 1) {
                    currentIndex++;
                } else {
                    currentIndex = 0;
                }
                updateSliderPosition();
                updateArrows();
                updateDots();
            }, 3000);
        }
    }

    window.moveLeft = moveLeft;
    window.moveRight = moveRight;
    window.toggleMultiPlayPause = function () {
        autoPlay = !autoPlay;
        if (autoPlay) {
            startAutoPlay();
            $('#multiPlayPauseBtn').text('⏸️');
        } else {
            clearInterval(interval);
            $('#multiPlayPauseBtn').text('▶️');
        }
    };

    $(window).on('resize', calculateSlideWidth);
}
