﻿(function ($) {
    var originalLoad = $.fn.load;
    $.fn.load = function (url, params, callback) {
        var lang = getCookie('lang') || 'en';
        var element = this;
        if (lang === 'hi') {
            var parts = url.split('/');
            var fileName = parts.pop();
            var folderPath = parts.join('/');
            var hiPath = folderPath + '/hi/' + fileName;

            return originalLoad.call(this, hiPath, params, function (response, status, xhr) {
                if (status === "error") {
                    originalLoad.call(element, url, params, function (response2, status2, xhr2) {
                        if (status2 === "error") {
                            element.html(`
                                <div style="text-align:center; padding:20px; border:1px solid #ccc;">
                                    <p>यह सामग्री हिंदी में उपलब्ध नहीं है।</p>
                                    <button onclick="redirectToEnglish('${window.location.pathname}')">अंग्रेज़ी में देखें</button>
                                </div>`);
                        } else {
                            if (typeof callback === 'function') callback(response2, status2, xhr2);
                        }
                    });
                } else {
                    if (typeof callback === 'function') callback(response, status, xhr);
                }
            });
        } else {
            return originalLoad.call(this, url, params, callback);
        }
    };

    function getCookie(name) {
        var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
        return match ? match[2] : null;
    }

    window.redirectToEnglish = function (returnUrl) {
        document.cookie = "lang=en; path=/";
        window.location.href = returnUrl;
    };
})(jQuery);
