﻿/* jshint esversion: 6 */

function resetAccessibility() {
    currentFontSize = 100;
    applyFontSizePercent(currentFontSize);

    document.body.classList.remove(
        "spacing-normal", "spacing-wide",
        "line-normal", "line-wide",
        "vspace-normal", "vspace-wide",
        "theme-default", "theme-black", "theme-gray", "theme-white"
    );

    document.getElementById("accessibilityToggleBtn")?.classList.remove("active");

    localStorage.removeItem("fontSpacing");
    localStorage.removeItem("lineSpacing");
    localStorage.removeItem("verticalSpacing");
    localStorage.removeItem("selectedTheme");
}

// Document Ready
$(document).ready(function () {
    console.log("✅ gigw.js loaded. Event handlers attached.");

    // Event Delegation for Skip to Main Content (for dynamically loaded toolbar)
    $(document).on('click', 'a.skip-link', function (e) {
        e.preventDefault();

        console.log("✅ Skip link clicked!");

        const target = document.getElementById("maincontent");
        if (target) {
            console.log("✅ Focusing #maincontent...");
            target.setAttribute("tabindex", "-1");
            target.focus();
            target.classList.add("focus-outline");
            setTimeout(() => {
                target.classList.remove("focus-outline");
                target.removeAttribute("tabindex");
                console.log("✅ Focus outline removed after 2s. User can press TAB to continue navigation.");
            }, 2000);
        } else {
            console.warn("❌ #maincontent not found!");
        }
    });






    // Bootstrap Tooltip Init
    const tooltipList = [].slice.call(document.querySelectorAll('[title]'));
    tooltipList.forEach(el => {
        if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
            new bootstrap.Tooltip(el);
        }
    });
});
