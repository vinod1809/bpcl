﻿/* jshint esversion: 6 */

let currentFontPx = parseFloat(localStorage.getItem("fontSizePx")) || 14;
const minFontPx = 10;
const maxFontPx = 18;
const stepPx = 2;

function applyFontSizePx(value) {
    console.log(`🔵 Applying font size: ${value}px`);
    document.documentElement.style.fontSize = value + 'px';
    localStorage.setItem("fontSizePx", value);
}

function adjustFontSize(action) {
    console.log(`🟡 Adjust font size action: ${action}`);
    if (action === 'increase' && currentFontPx < maxFontPx) {
        currentFontPx = Math.min(currentFontPx + stepPx, maxFontPx);
    } else if (action === 'decrease' && currentFontPx > minFontPx) {
        currentFontPx = Math.max(currentFontPx - stepPx, minFontPx);
    } else if (action === 'reset') {
        currentFontPx = 14;
    }
    applyFontSizePx(currentFontPx);
}

function changeFontSize(value) {
    console.log(`🟢 changeFontSize called with value: ${value}`);
    if (value === 'small') {
        adjustFontSize('decrease');
    } else if (value === 'large') {
        adjustFontSize('increase');
    } else {
        adjustFontSize('reset');
    }
}

// Auto-bind when #includedToolbar appears using MutationObserver
document.addEventListener("DOMContentLoaded", function () {
    console.log("✅ fontSizeController.js loaded — Waiting for toolbar...");

    applyFontSizePx(currentFontPx);

    const observer = new MutationObserver(function (mutations, obs) {
        const fontIcon = document.querySelector("#fontSizeDropdown img");
        const fontPopup = document.getElementById("fontSizePopup");

        if (fontIcon && fontPopup) {
            console.log("✅ Toolbar detected — Binding font size events.");

            fontIcon.addEventListener("click", function (e) {
                e.stopPropagation();
                fontPopup.style.display = (fontPopup.style.display === "block") ? "none" : "block";
                console.log(`🟠 Font icon clicked. Popup is now: ${fontPopup.style.display}`);
            });

            fontPopup.addEventListener("click", function (e) {
                e.stopPropagation();
            });

            document.addEventListener("click", function () {
                if (fontPopup.style.display === "block") {
                    fontPopup.style.display = "none";
                    console.log("🔵 Clicked outside. Hiding font size popup.");
                }
            });

            obs.disconnect(); // Stop observing after binding once
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });
});
