﻿(function () {
    console.log("✅ Language Switcher JS Loaded — Watching for languageSwitcher...");

    const langMap = { hi: "हिंदी", en: "English" };
    const loaderTextMap = {
        hi: "भाषा बदली जा रही है...",
        en: "Switching language..."
    };

    function initializeSwitcher() {
        const languageSwitcher = document.getElementById("languageSwitcher");
        const currentLangSpan = document.getElementById("currentLang");

        if (!languageSwitcher || !currentLangSpan) {
            console.warn("❗ languageSwitcher or currentLang not found — waiting...");
            return false;
        }

        const serverLang = languageSwitcher.getAttribute("data-server-lang") || "en";
        const setLangBaseUrl = languageSwitcher.getAttribute("data-lang-url") || "/LanguageHandler.ashx";
        const altLang = serverLang === "hi" ? "en" : "hi";

        currentLangSpan.innerHTML = `
            <span id="langSwitchLink" class="language-link" data-lang="${altLang}" style="cursor:pointer; font-weight:bold;">
                ${langMap[altLang]}
            </span>`;

        console.log(`✅ Language button added — Now binding click for: ${langMap[altLang]}`);

        document.getElementById("langSwitchLink").addEventListener("click", function (e) {
            e.preventDefault();
            console.log(`✅ Language button clicked — Switching to: ${altLang}`);

            const langLoader = document.getElementById("langLoader");
            const langLoaderText = document.getElementById("langLoaderText");

            if (langLoader) {
                if (langLoaderText) {
                    langLoaderText.textContent = loaderTextMap[altLang] || "Switching language...";
                }
                langLoader.style.display = "block";
            }

            setTimeout(() => {
                window.location.href = `${setLangBaseUrl}?lang=${altLang}&returnUrl=${encodeURIComponent(window.location.pathname)}`;
            }, 100);
        });

        return true;
    }

    // Wait for DOM + Toolbar loaded
    document.addEventListener("DOMContentLoaded", function () {
        const interval = setInterval(function () {
            if (initializeSwitcher()) {
                clearInterval(interval);
            }
        }, 300);
    });
})();
