﻿let currentFontSize = parseFloat(localStorage.getItem("fontSizeValue")) || 100;

const defaultFontPx = 14;
const minFontPx = 10;
const maxFontPx = 18;
const stepPx = 2;

const pxToPercent = px => (px / defaultFontPx) * 100;
const minPercent = pxToPercent(minFontPx);    // ~71.43%
const maxPercent = pxToPercent(maxFontPx);    // ~128.57%
const stepPercent = pxToPercent(stepPx);      // ~14.29%

function applyFontSizePercent(value) {
    document.documentElement.style.fontSize = value.toFixed(2) + '%';
    localStorage.setItem("fontSizeValue", value.toFixed(2));
}

function adjustFontSize(action) {
    if (action === 'increase' && currentFontSize < maxPercent) {
        currentFontSize = Math.min(currentFontSize + stepPercent, maxPercent);
    } else if (action === 'decrease' && currentFontSize > minPercent) {
        currentFontSize = Math.max(currentFontSize - stepPercent, minPercent);
    } else if (action === 'reset') {
        currentFontSize = 100;
    }
    applyFontSizePercent(currentFontSize);
}


function changeFontSize(value) {
    if (value === 'small') {
        adjustFontSize('decrease');
    } else if (value === 'large') {
        adjustFontSize('increase');
    } else {
        adjustFontSize('reset');
    }
}

// -------------------------------
// 🔤 Font & Line Spacing Modules
// -------------------------------
function setFontSpacing(level) {
    document.body.classList.remove("spacing-normal", "spacing-wide");
    document.body.classList.add("spacing-" + level);
    localStorage.setItem("fontSpacing", level);
}

function setLineSpacing(level) {
    document.body.classList.remove("line-normal", "line-wide");
    document.body.classList.add("line-" + level);
    localStorage.setItem("lineSpacing", level);
}

// ------------------------------
// ↕ Vertical Spacing Toggle
// ------------------------------
// 📌 Toggle Vertical (Line) Spacing
function toggleLineSpacing() {
    const body = document.body;
    const btn = document.getElementById("accessibilityToggleBtn");

    const isWide = body.classList.contains("line-wide");

    // Toggle class
    body.classList.remove("line-normal", "line-wide");
    body.classList.add(isWide ? "line-normal" : "line-wide");

    // Save in localStorage
    localStorage.setItem("lineSpacing", isWide ? "normal" : "wide");

    // Toggle active class
    btn?.classList.toggle("active", !isWide);
}


// -----------------------------
// 🎨 Theme Switcher (Single Definition)
// -----------------------------
const storedTheme = localStorage.getItem("selectedTheme") || "default";
function setTheme(theme) {
    // Remove all known theme classes from <body>
    document.body.classList.remove("theme-black", "theme-gray");

    // Only add if not default
    if (theme === "black" || theme === "gray") {
        document.body.classList.add("theme-" + theme);
    }

    // Save selection
    localStorage.setItem("selectedTheme", theme);
}


// --------------------
// 🔁 Reset All Settings
// --------------------
function resetAccessibility() {
    currentFontSize = 100;
    applyFontSizePercent(currentFontSize);

    document.body.classList.remove(
        "spacing-normal", "spacing-wide",
        "line-normal", "line-wide",
        "vspace-normal", "vspace-wide",
        "theme-default", "theme-black", "theme-gray", "theme-white"
    );

    document.getElementById("accessibilityToggleBtn")?.classList.remove("active");

    localStorage.removeItem("fontSizeValue");
    localStorage.removeItem("fontSpacing");
    localStorage.removeItem("lineSpacing");
    localStorage.removeItem("verticalSpacing");
    localStorage.removeItem("selectedTheme");
}

//--------------------
////📦 Load Saved Settings
//--------------------

document.addEventListener("DOMContentLoaded", function () {
    // Font Size
    const storedSize = parseFloat(localStorage.getItem("fontSizeValue"));
    if (storedSize >= minPercent && storedSize <= maxPercent) {
        currentFontSize = storedSize;
        applyFontSizePercent(currentFontSize);
    } else {
        applyFontSizePercent(100);
    }

    // Font Spacing
    if (localStorage.getItem("fontSpacing")) {
        setFontSpacing(localStorage.getItem("fontSpacing"));
    }

    // Line Spacing
    if (localStorage.getItem("lineSpacing")) {
        setLineSpacing(localStorage.getItem("lineSpacing"));
    }

    // Vertical Spacing
    if (localStorage.getItem("verticalSpacing")) {
        const level = localStorage.getItem("verticalSpacing");
        document.body.classList.add("vspace-" + level);
        if (level === "wide") {
            document.getElementById("accessibilityToggleBtn")?.classList.add("active");
        }
    }

    // Theme

    setTheme(storedTheme);

    // ⏩ Skip to Main Content
    const skipLink = document.getElementById("skipLink");
    skipLink?.addEventListener("click", function (e) {
        e.preventDefault();
        const target = document.getElementById("maincontent");
        if (target) {
            target.setAttribute("tabindex", "-1");
            target.focus();
            target.classList.add("focus-outline");
            setTimeout(() => {
                target.classList.remove("focus-outline");
                target.removeAttribute("tabindex");
            }, 2000);
        }
    });

    // Font Size Dropdown Toggle
    const fontIcon = document.querySelector("#fontSizeDropdown img");
    const fontPopup = document.getElementById("fontSizePopup");

    fontIcon?.addEventListener("click", function (e) {
        e.stopPropagation();
        fontPopup.style.display = (fontPopup.style.display === "block") ? "none" : "block";
    });

    fontPopup?.addEventListener("click", e => e.stopPropagation());

    document.addEventListener("click", () => {
        fontPopup.style.display = "none";
    });


    // Theme Switcher links
    setTheme(storedTheme);

    // Bootstrap Tooltip
    const tooltipList = [].slice.call(document.querySelectorAll('[title]'));
    tooltipList.forEach(el => {
        new bootstrap.Tooltip(el);
    });

    // Vertical spacing toggle
    document.getElementById("accessibilityToggleBtn")?.addEventListener("click", toggleLineSpacing);

});

// Letter Spacing Toggle


function toggleLetterSpacing() {
    const isWide = document.body.classList.contains("spacing-wide");
    setFontSpacing(isWide ? "normal" : "wide");
}

// Language Switcher Action