﻿function resetAccessibility() {
    currentFontSize = 100;
    applyFontSizePercent(currentFontSize);

    document.body.classList.remove(
        "spacing-normal", "spacing-wide",
        "line-normal", "line-wide",
        "vspace-normal", "vspace-wide",
        "theme-default", "theme-black", "theme-gray", "theme-white"
    );

    document.getElementById("accessibilityToggleBtn")?.classList.remove("active");

    localStorage.removeItem("fontSpacing");
    localStorage.removeItem("lineSpacing");
    localStorage.removeItem("verticalSpacing");
    localStorage.removeItem("selectedTheme");
    localStorage.removeItem("selectedTheme");
    localStorage.removeItem("selectedTheme");
}

document.addEventListener("DOMContentLoaded", function () {
    // Skip to Main Content
    const skipLink = document.getElementById("skipLink");
    skipLink?.addEventListener("click", function (e) {
        e.preventDefault();
        const target = document.getElementById("maincontent");
        if (target) {
            target.setAttribute("tabindex", "-1");
            target.focus();
            target.classList.add("focus-outline");
            setTimeout(() => {
                target.classList.remove("focus-outline");
                target.removeAttribute("tabindex");
            }, 2000);
        }
    });

 

    // Bootstrap Tooltip Init
    const tooltipList = [].slice.call(document.querySelectorAll('[title]'));
    tooltipList.forEach(el => {
        new bootstrap.Tooltip(el);
    });
});
