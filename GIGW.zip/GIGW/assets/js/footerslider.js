﻿

//var wrapper, slides, totalSlides;
//var visibleSlides = 4;
//var currentIndex = 0;
//var isAutoPlay = true;
//var userPaused = false;
//var autoPlayInterval;
//var interactionTimeout;

//document.addEventListener("DOMContentLoaded", function () {
//    wrapper = document.getElementById("multiSliderWrapper");
//    var sliderContainer = document.querySelector(".multi-slider-container");

//    if (!wrapper || !sliderContainer) return;

//    slides = wrapper.querySelectorAll(".multi-slide-wrapper");
//    totalSlides = slides.length;
//    if (totalSlides === 0) return;

//    createDots();
//    updateSlider();
//    updateArrowState();
//    startAutoPlay();

//    sliderContainer.addEventListener("mouseenter", pauseTemporarily);
//    sliderContainer.addEventListener("mouseleave", resumeAutoIfAllowed);
//    window.addEventListener("resize", updateSlider);
//});


//function moveRight() {
//    pauseTemporarily();
//    if (currentIndex < totalSlides - visibleSlides) {
//        currentIndex++;
//        updateSlider();
//    }
//}

//function moveLeft() {
//    pauseTemporarily();
//    if (currentIndex > 0) {
//        currentIndex--;
//        updateSlider();
//    }
//}

//function autoSlideRight() {
//    if (currentIndex < totalSlides - visibleSlides) {
//        currentIndex++;
//    } else {
//        currentIndex = 0;
//    }
//    updateSlider();
//}

//function toggleMultiPlayPause() {
//    var btn = document.getElementById("multiPlayPauseBtn");
//    if (!btn) return;

//    if (isAutoPlay) {
//        clearInterval(autoPlayInterval);
//        btn.innerHTML = "▶️";
//        isAutoPlay = false;
//        userPaused = true;
//    } else {
//        isAutoPlay = true;
//        userPaused = false;
//        startAutoPlay();
//        btn.innerHTML = "⏸️";
//    }
//}

//function updateSlider() {
//    if (!slides || slides.length === 0) return;
//    var slideWidth = slides[0].offsetWidth;
//    wrapper.style.transform = "translateX(-" + (currentIndex * slideWidth) + "px)";
//    updateArrowState();
//    updateDots();
//}

//function startAutoPlay() {
//    clearInterval(autoPlayInterval);
//    autoPlayInterval = setInterval(autoSlideRight, 3000);
//}

//function pauseTemporarily() {
//    if (!userPaused) {
//        clearInterval(autoPlayInterval);
//        if (interactionTimeout) clearTimeout(interactionTimeout);
//        interactionTimeout = setTimeout(function () {
//            if (!userPaused && isAutoPlay) startAutoPlay();
//        }, 8000);
//    }
//}

//function resumeAutoIfAllowed() {
//    if (!userPaused && isAutoPlay) {
//        startAutoPlay();
//    }
//}

//function updateArrowState() {
//    var leftArrow = document.getElementById("arrowLeft");
//    var rightArrow = document.getElementById("arrowRight");

//    if (!leftArrow || !rightArrow) return;

//    leftArrow.disabled = currentIndex <= 0;
//    rightArrow.disabled = currentIndex >= totalSlides - visibleSlides;
//}

//function createDots() {
//    var dotsContainer = document.getElementById("multiSliderDots");
//    if (!dotsContainer) return;

//    dotsContainer.innerHTML = "";

//    for (var i = 0; i < totalSlides; i++) {
//        var dot = document.createElement("span");
//        dot.classList.add("dot");
//        dot.dataset.index = i;

//        dot.addEventListener("click", function () {
//            currentIndex = parseInt(this.dataset.index);
//            pauseTemporarily();
//            updateSlider();
//        });

//        dotsContainer.appendChild(dot);
//    }

//    updateDots();
//}


//function updateDots() {
//    var allDots = document.querySelectorAll("#multiSliderDots .dot");

//    allDots.forEach(function (dot, idx) {
//        dot.classList.toggle("active", idx === currentIndex);
//    });
//}







var wrapper, slides, totalSlides;
var visibleSlides = 4;
var currentIndex = 0;
var isAutoPlay = true;
var userPaused = false;
var autoPlayInterval;
var interactionTimeout;

document.addEventListener("DOMContentLoaded", function () {
    fetch('/GIGW/assets/urlfile.json')
        .then(response => response.json())
        .then(urlData => {
            document.querySelectorAll(".multi-slide-wrapper").forEach(wrapperItem => {
                var imgName = wrapperItem.getAttribute("data-image-name");
                var match = urlData.find(u => u.image.toLowerCase() === imgName.toLowerCase());
                var img = wrapperItem.querySelector("img");
                var anchor = document.createElement("a");

                if (match) {
                    console.log(` URL found for image: ${imgName} => ${match.url}`);
                    anchor.href = match.url;
                    anchor.target = "_blank";
                } else {
                    console.log(` No URL found for image: ${imgName}`);
                    anchor.href = "#";
                }

                anchor.style.display = "block";
                anchor.appendChild(img.cloneNode(true));
                wrapperItem.innerHTML = "";
                wrapperItem.appendChild(anchor);
            });

            initializeSlider();  // ✅ Initialize after URL binding
        })
        .catch(err => {
            console.error("❗ Error loading URL JSON:", err);
            initializeSlider();  // ✅ Still initialize slider even if JSON fails
        });
});

function initializeSlider() {
    wrapper = document.getElementById("multiSliderWrapper");
    var sliderContainer = document.querySelector(".multi-slider-container");

    if (!wrapper || !sliderContainer) return;

    slides = wrapper.querySelectorAll(".multi-slide-wrapper");
    totalSlides = slides.length;
    if (totalSlides === 0) return;

    createDots();
    updateSlider();
    updateArrowState();
    startAutoPlay();

    sliderContainer.addEventListener("mouseenter", pauseTemporarily);
    sliderContainer.addEventListener("mouseleave", resumeAutoIfAllowed);
    window.addEventListener("resize", updateSlider);
}

function moveRight() {
    pauseTemporarily();
    if (currentIndex < totalSlides - visibleSlides) {
        currentIndex++;
        updateSlider();
    }
}

function moveLeft() {
    pauseTemporarily();
    if (currentIndex > 0) {
        currentIndex--;
        updateSlider();
    }
}

function autoSlideRight() {
    if (currentIndex < totalSlides - visibleSlides) {
        currentIndex++;
    } else {
        currentIndex = 0;
    }
    updateSlider();
}

function toggleMultiPlayPause() {
    var btn = document.getElementById("multiPlayPauseBtn");
    if (!btn) return;

    if (isAutoPlay) {
        clearInterval(autoPlayInterval);
        btn.innerHTML = "▶️";
        isAutoPlay = false;
        userPaused = true;
    } else {
        isAutoPlay = true;
        userPaused = false;
        startAutoPlay();
        btn.innerHTML = "⏸️";
    }
}

function updateSlider() {
    if (!slides || slides.length === 0) return;
    var slideWidth = slides[0].offsetWidth;
    wrapper.style.transform = "translateX(-" + (currentIndex * slideWidth) + "px)";
    updateArrowState();
    updateDots();
}

function startAutoPlay() {
    clearInterval(autoPlayInterval);
    autoPlayInterval = setInterval(autoSlideRight, 3000);
}

function pauseTemporarily() {
    if (!userPaused) {
        clearInterval(autoPlayInterval);
        if (interactionTimeout) clearTimeout(interactionTimeout);
        interactionTimeout = setTimeout(function () {
            if (!userPaused && isAutoPlay) startAutoPlay();
        }, 8000);
    }
}

function resumeAutoIfAllowed() {
    if (!userPaused && isAutoPlay) {
        startAutoPlay();
    }
}

function updateArrowState() {
    var leftArrow = document.getElementById("arrowLeft");
    var rightArrow = document.getElementById("arrowRight");

    if (!leftArrow || !rightArrow) return;

    leftArrow.disabled = currentIndex <= 0;
    rightArrow.disabled = currentIndex >= totalSlides - visibleSlides;
}

function createDots() {
    var dotsContainer = document.getElementById("multiSliderDots");
    if (!dotsContainer) return;

    dotsContainer.innerHTML = "";

    for (var i = 0; i < totalSlides; i++) {
        var dot = document.createElement("span");
        dot.classList.add("dot");
        dot.dataset.index = i;

        dot.addEventListener("click", function () {
            currentIndex = parseInt(this.dataset.index);
            pauseTemporarily();
            updateSlider();
        });

        dotsContainer.appendChild(dot);
    }

    updateDots();
}

function updateDots() {
    var allDots = document.querySelectorAll("#multiSliderDots .dot");
    allDots.forEach(function (dot, idx) {
        dot.classList.toggle("active", idx === currentIndex);
    });
}










