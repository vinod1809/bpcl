﻿document.addEventListener("DOMContentLoaded", function () {
    const wrapper = document.getElementById("multiSliderWrapper");
    const slides = wrapper.querySelectorAll(".multi-slide");
    const totalSlides = slides.length;
    const visibleSlides = 4;
    let currentIndex = 0;
    let isAutoPlay = true;
    let slideWidth = slides[0].offsetWidth;
    let autoPlayInterval = setInterval(moveRight, 3000);

    function updateSlider() {
        slideWidth = slides[0].offsetWidth;
        wrapper.style.transform = `translateX(-${currentIndex * slideWidth}px)`;
    }

    window.moveRight = function () {
        if (currentIndex < totalSlides - visibleSlides) {
            currentIndex++;
        } else {
            currentIndex = 0;
        }
        updateSlider();
    };

    window.moveLeft = function () {
        if (currentIndex > 0) {
            currentIndex--;
        } else {
            currentIndex = totalSlides - visibleSlides;
        }
        updateSlider();
    };

    window.toggleMultiPlayPause = function () {
        const btn = document.getElementById("multiPlayPauseBtn");
        if (isAutoPlay) {
            clearInterval(autoPlayInterval);
            btn.innerHTML = "▶️";
        } else {
            autoPlayInterval = setInterval(moveRight, 3000);
            btn.innerHTML = "⏸️";
        }
        isAutoPlay = !isAutoPlay;
    };

    window.addEventListener("resize", updateSlider);
    updateSlider();
});
