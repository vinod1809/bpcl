﻿document.addEventListener("DOMContentLoaded", function () {
    const langMap = { hi: "हिंदी", en: "English" };
    const currentLangSpan = document.getElementById("currentLang");
    const altLangBox = document.getElementById("altLangBox");
    const languageSwitcher = document.getElementById("languageSwitcher");

    let currentLang = localStorage.getItem("selectedLang") || "hi";

    function updateLanguageUI(lang) {
        const altLang = lang === "hi" ? "en" : "hi";
        currentLangSpan.innerHTML = `<span class="language-link" data-lang="${lang}" style="cursor:pointer;">${langMap[lang]}</span>`;
        altLangBox.innerHTML = `<a href="#" class="language-link" data-lang="${altLang}" style="display:block; padding:4px;">${langMap[altLang]}</a>`;
        localStorage.setItem("selectedLang", lang);
    }

    updateLanguageUI(currentLang);

    currentLangSpan.addEventListener("click", function (e) {
        e.stopPropagation();
        altLangBox.style.display = (altLangBox.style.display === "block") ? "none" : "block";
    });

    altLangBox.addEventListener("click", function (e) {
        e.preventDefault();
        const langLink = e.target.closest(".language-link");
        if (langLink) {
            const selectedLang = langLink.getAttribute("data-lang");
            if (selectedLang && selectedLang !== currentLang) {
                currentLang = selectedLang;
                updateLanguageUI(currentLang);
                altLangBox.style.display = "none";
                switchLanguage(currentLang);
            }
        }
    });

    document.addEventListener("click", function (e) {
        if (!languageSwitcher.contains(e.target)) {
            altLangBox.style.display = "none";
        }
    });

    function switchLanguage(lang) {
        fetch(`/Home/SetLanguage?lang=${lang}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" }
        }).then(() => location.reload());
    }
});