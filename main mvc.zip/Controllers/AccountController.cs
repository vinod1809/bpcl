﻿using GIGWCompliantSite.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace GIGWCompliantSite.Controllers
{
 // GET: Account
        public class AccountController : Controller
        {
            [HttpGet]
            public ActionResult Login()
            {
                return View();
            }

        [HttpPost]
        public ActionResult Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Dummy authentication check
            if (model.Username == "admin" && model.Password == "password")
            {
                // ✅ This is the missing line!
                FormsAuthentication.SetAuthCookie(model.Username, false); // false = don't remember me

                return RedirectToAction("Index", "Home");
            }

            ModelState.AddModelError("", "Invalid username or password");
            return View(model);
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }

    }



}
