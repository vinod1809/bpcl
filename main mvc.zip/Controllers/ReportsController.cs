﻿using GIGWCompliantSite.Models;
using System.Collections.Generic;
using System.Web.Mvc;

namespace GIGWCompliantSite.Controllers
{
    public class ReportsController : Controller
    {
        public ActionResult Index()
        {
            var reportData = new List<ReportItem>
            {
                new ReportItem { Service = "Service A", Usage = 120 },
                new ReportItem { Service = "Service B", Usage = 95 },
                new ReportItem { Service = "Service C", Usage = 140 },
            };

            return View(reportData);
        }
    }
}
