﻿using System;
using System.Web;
using System.Web.Mvc;

namespace GIGWCompliantSite.Controllers
{
    public class LanguageController : Controller
    {

        //public ActionResult SetLanguage(string lang)
        //{
        //    try
        //    {
        //        if (string.IsNullOrEmpty(lang)) lang = "en";

        //        Session["lang"] = lang;
        //        Response.Cookies.Add(new HttpCookie("lang", lang)
        //        {
        //            Expires = DateTime.Now.AddYears(1),
        //            Path = "/"
        //        });

        //        var refUrl = Request.UrlReferrer?.GetLeftPart(UriPartial.Path) ?? Url.Action("Index", "Home");

        //        // Append lang query param
        //        var uriBuilder = new UriBuilder(refUrl);
        //        var query = HttpUtility.ParseQueryString(uriBuilder.Query);
        //        query["lang"] = lang;
        //        uriBuilder.Query = query.ToString();

        //        return Redirect(uriBuilder.ToString());
        //    }
        //    catch
        //    {
        //        return RedirectToAction("Index", "Home");
        //    }
        //}

        public ActionResult SetLanguage(string lang)
        {
            try
            {
                if (string.IsNullOrEmpty(lang)) lang = "en";

                Session["lang"] = lang;
                Response.Cookies.Add(new HttpCookie("lang", lang)
                {
                    Expires = DateTime.Now.AddYears(1),
                    Path = "/"
                });

                var refUrl = Request.UrlReferrer?.GetLeftPart(UriPartial.Path) ?? Url.Action("Index", "Home");

                var uriBuilder = new UriBuilder(refUrl);
                var query = HttpUtility.ParseQueryString(uriBuilder.Query);

                if (!lang.Equals("en", StringComparison.OrdinalIgnoreCase))
                {
                    query["lang"] = lang;  // Only append if NOT English
                }
                else
                {
                    query.Remove("lang");  // Remove lang param if exists
                }

                uriBuilder.Query = query.ToString();

                return Redirect(uriBuilder.ToString());
            }
            catch
            {
                return RedirectToAction("Index", "Home");
            }
        }


        public ActionResult ForceRedirect(string returnUrl)
        {
            return Redirect(returnUrl);
        }

        public ActionResult HindiNotAvailable()
        {
            try
            {
                string returnUrl = TempData["ReturnUrl"] as string;
                if (string.IsNullOrEmpty(returnUrl))
                {
                    return RedirectToAction("Index", "Home");
                }

                ViewBag.ReturnUrl = Url.Action("ForceEnglishRedirect", "Language", new { returnUrl });
                return View(); // HindiNotAvailable.cshtml
            }
            catch
            {
                return RedirectToAction("Index", "Home");
            }
        }

        public ActionResult ForceEnglishRedirect(string returnUrl)
        {
            try
            {
                Session["lang"] = "en";
                Response.Cookies.Add(new HttpCookie("lang", "en")
                {
                    Expires = DateTime.Now.AddYears(1),
                    Path = "/"
                });

                return Redirect(returnUrl ?? Url.Action("Index", "Home"));
            }
            catch
            {
                return RedirectToAction("Index", "Home");
            }
        }
    }
}





