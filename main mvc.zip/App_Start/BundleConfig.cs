﻿//using System.Web;
//using System.Web.Optimization;

//namespace GIGWCompliantSite
//{
//    public class BundleConfig
//    {
//        public static void RegisterBundles(BundleCollection bundles)
//        {
//            // jQuery & Validation
//            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
//                        "~/Scripts/jquery-{version}.js"));

//            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
//                        "~/Scripts/jquery.validate*"));

//            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
//                        "~/Scripts/modernizr-*"));

//            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
//                      "~/Scripts/bootstrap.js"));

//            bundles.Add(new StyleBundle("~/Content/css").Include(
//                      "~/Content/bootstrap.css",
//                      "~/Content/site.css"));


//        }
//    }
//}

//using System.Web;
//using System.Web.Optimization;

//namespace GIGWCompliantSite
//{
//    public class BundleConfig
//    {
//        public static void RegisterBundles(BundleCollection bundles)
//        {
//            // jQuery & Validation
//            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
//                "~/Scripts/jquery-{version}.js"
//            ));

//            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
//                "~/Scripts/jquery.validate*"
//            ));

//            // Modernizr
//            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
//                "~/Scripts/modernizr-*"
//            ));

//            // Project Bootstrap
//            bundles.Add(new Bundle("~/bundles/bootstrap").Include(
//                "~/Scripts/bootstrap.js"
//            ));

//            // Project CSS
//            bundles.Add(new StyleBundle("~/Content/css").Include(
//                "~/Content/bootstrap.css",
//                "~/Content/site.css"
//            ));

//            // ===========================
//            // GIGW Section Starts Here
//            // ===========================

//            // GIGW Bootstrap (Separate)
//            bundles.Add(new StyleBundle("~/bundles/gigwBootstrapCss").Include(
//                "~/GIGW/bootstrap/css/bootstrap.min.css"
//            ));

//            bundles.Add(new ScriptBundle("~/bundles/gigwBootstrapJs").Include(
//                "~/GIGW/bootstrap/js/bootstrap.bundle.min.js"
//            ));

//            // GIGW JS (without Bootstrap)
//            bundles.Add(new ScriptBundle("~/bundles/customGigwScripts").Include(
//                "~/GIGW/assets/js/fontSizeController.js",
//                "~/GIGW/assets/js/fontspacing.js",
//                "~/GIGW/assets/js/linespacing.js",
//                "~/GIGW/assets/js/verticalspacing.js",
//                "~/GIGW/assets/js/languageSwitcherGIGW.js",
//                "~/GIGW/assets/js/footerslider.js",
//                "~/GIGW/assets/js/gigwtheme.js",
//                "~/GIGW/assets/js/main.js",
//                "~/GIGW/assets/js/gigw.js"
//            ));




//            // GIGW CSS (without Bootstrap)
//            bundles.Add(new StyleBundle("~/bundles/customGigwCss").Include(
//                "~/GIGW/assets/css/gigwfontresize.css",
//                "~/GIGW/assets/css/footerslider.css",
//                "~/GIGW/assets/css/gigw-theme-black.css",
//                "~/GIGW/assets/css/gigw-theme-gray.css",
//                "~/GIGW/assets/css/main.css",
//                "~/GIGW/assets/css/gigw.css"
//            ));
//        }
//    }
//}


using System.Web;
using System.Web.Optimization;
using NUglify;

namespace GIGWCompliantSite
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            // ===========================
            // Default Project Bundles
            // ===========================

            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                "~/Scripts/jquery-{version}.js"
            ).WithNUglifyJs());

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                "~/Scripts/jquery.validate*"
            ).WithNUglifyJs());

            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                "~/Scripts/modernizr-*"
            ).WithNUglifyJs());

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                "~/Scripts/bootstrap.js"
            ).WithNUglifyJs());

            bundles.Add(new StyleBundle("~/Content/css").Include(
                "~/Content/bootstrap.css",
                "~/Content/site.css"
            ).WithNUglifyCss());

            // ===========================
            // GIGW Bundles
            // ===========================

            bundles.Add(new StyleBundle("~/bundles/gigwBootstrapCss").Include(
                "~/GIGW/bootstrap/css/bootstrap.min.css"
            ).WithNUglifyCss());

            bundles.Add(new ScriptBundle("~/bundles/gigwBootstrapJs").Include(
                "~/GIGW/bootstrap/js/bootstrap.bundle.min.js"
            ).WithNUglifyJs());

            bundles.Add(new ScriptBundle("~/bundles/customGigwScripts").Include(
                "~/GIGW/assets/js/fontSizeController.js",
                "~/GIGW/assets/js/fontspacing.js",
                "~/GIGW/assets/js/linespacing.js",
                "~/GIGW/assets/js/verticalspacing.js",
                "~/GIGW/assets/js/languageSwitcherGIGW.js",
                "~/GIGW/assets/js/footerslider.js",
                "~/GIGW/assets/js/gigwtheme.js",
                "~/GIGW/assets/js/main.js",
                "~/GIGW/assets/js/gigw.js"
            ).WithNUglifyJs());

            bundles.Add(new StyleBundle("~/bundles/customGigwCss").Include(
                "~/GIGW/assets/css/gigwfontresize.css",
                "~/GIGW/assets/css/footerslider.css",
                "~/GIGW/assets/css/gigw-theme-black.css",
                "~/GIGW/assets/css/gigw-theme-gray.css",
                "~/GIGW/assets/css/main.css",
                "~/GIGW/assets/css/gigw.css"
            ).WithNUglifyCss());
        }
    }

    // =====================
    // NUglify Transform Helpers
    // =====================
    public static class BundleExtensions
    {
        public static Bundle WithNUglifyJs(this Bundle bundle)
        {
            bundle.Transforms.Clear();
            bundle.Transforms.Add(new NUglifyJsTransform());
            return bundle;
        }

        public static Bundle WithNUglifyCss(this Bundle bundle)
        {
            bundle.Transforms.Clear();
            bundle.Transforms.Add(new NUglifyCssTransform());
            return bundle;
        }
    }

    public class NUglifyJsTransform : IBundleTransform
    {
        public void Process(BundleContext context, BundleResponse response)
        {
            var result = Uglify.Js(response.Content);
            response.Content = result.HasErrors ? response.Content : result.Code;
            response.ContentType = "text/javascript";
        }
    }

    public class NUglifyCssTransform : IBundleTransform
    {
        public void Process(BundleContext context, BundleResponse response)
        {
            var result = Uglify.Css(response.Content);
            response.Content = result.HasErrors ? response.Content : result.Code;
            response.ContentType = "text/css";
        }
    }
}
