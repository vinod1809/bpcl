﻿using System.Collections.Generic;

namespace GIGWCompliantSite.Models
{
    public class VisitorCounter
    {
        public int Total { get; set; } = 0;
        public int CurrentDay { get; set; } = 0;
        public Dictionary<string, int> Daily { get; set; } = new Dictionary<string, int>();
    }
}
