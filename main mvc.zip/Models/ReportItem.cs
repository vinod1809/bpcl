﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GIGWCompliantSite.Models
{
    public class ReportItem
    {
        public string Service { get; set; }
        public int Usage { get; set; }
    }
}
