﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web;
using GIGWCompliantSite.Models;

namespace GIGWCompliantSite.Utilities
{
    public static class VisitorAggregator
    {
        public static VisitorCounter GetAggregatedStats()
        {
            var filePath = HttpContext.Current.Server.MapPath("~/App_Data/visitor_daily_summary.csv");
            var stats = new VisitorCounter();

            if (!File.Exists(filePath))
                return stats;

            try
            {
                foreach (var line in File.ReadAllLines(filePath))
                {
                    var parts = line.Split(',');
                    if (parts.Length == 2 && int.TryParse(parts[1], out var count))
                    {
                        stats.Total += count;
                        stats.Daily[parts[0]] = count;
                    }
                }

                var today = DateTime.UtcNow.ToString("yyyy-MM-dd");
                stats.CurrentDay = stats.Daily.ContainsKey(today) ? stats.Daily[today] : 0;
            }
            catch
            {
                // Optional: Log error
            }

            return stats;
        }
    }
}
