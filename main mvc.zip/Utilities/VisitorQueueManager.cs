﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

namespace GIGWCompliantSite.Utilities
{
    public static class VisitorQueueManager
    {
        private static readonly ConcurrentQueue<string> VisitorQueue = new ConcurrentQueue<string>();
        private static readonly string FilePath = HttpContext.Current.Server.MapPath("~/App_Data/visitor_daily_summary.csv");
        private static string LastFlushedDate = DateTime.UtcNow.ToString("yyyy-MM-dd");
        private static readonly object LockObj = new object();

        public static void TrackVisitor()
        {
            var today = DateTime.UtcNow.ToString("yyyy-MM-dd");
            VisitorQueue.Enqueue(today);

            if (today != LastFlushedDate)
            {
                // New day, flush and reset last flushed date
                lock (LockObj)
                {
                    FlushToFile();
                    LastFlushedDate = today;
                }
            }
        }

        public static void ForceFinalFlush()
        {
            lock (LockObj)
            {
                FlushToFile();
            }
        }

        private static void FlushToFile()
        {
            if (VisitorQueue.IsEmpty) return;

            try
            {
                var dailyCounts = new Dictionary<string, int>();

                if (File.Exists(FilePath))
                {
                    foreach (var line in File.ReadAllLines(FilePath))
                    {
                        var parts = line.Split(',');
                        if (parts.Length == 2 && int.TryParse(parts[1], out var count))
                        {
                            dailyCounts[parts[0]] = count;
                        }
                    }
                }

                var queueCounts = new Dictionary<string, int>();
                while (VisitorQueue.TryDequeue(out var date))
                {
                    if (queueCounts.ContainsKey(date))
                        queueCounts[date]++;
                    else
                        queueCounts[date] = 1;
                }

                foreach (var kvp in queueCounts)
                {
                    if (dailyCounts.ContainsKey(kvp.Key))
                        dailyCounts[kvp.Key] += kvp.Value;
                    else
                        dailyCounts[kvp.Key] = kvp.Value;
                }

                var sb = new StringBuilder();
                foreach (var kvp in dailyCounts.OrderBy(x => x.Key))
                {
                    sb.AppendLine($"{kvp.Key},{kvp.Value}");
                }

                File.WriteAllText(FilePath, sb.ToString());
            }
            catch
            {
                // Optional: Log error
            }
        }
      

    }
}
