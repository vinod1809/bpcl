﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;

namespace GIGWCompliantSite.ActionFilter
{
    public class CombinedFilterProvider : FilterAttributeFilterProvider
    {
        public override IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {
            var filters = new List<Filter>(base.GetFilters(controllerContext, actionDescriptor));

            try
            {
                var context = controllerContext.HttpContext;
                var session = context.Session;
                var request = context.Request;
                var response = context.Response;

                if (session != null && session["lang"] == null)
                {
                    string cookieLang = request.Cookies["lang"]?.Value?.ToLower();
                    string lang = string.IsNullOrEmpty(cookieLang) ? "en" : cookieLang;

                    session["lang"] = lang;

                    if (string.IsNullOrEmpty(cookieLang))
                    {
                        response.Cookies.Add(new HttpCookie("lang", lang)
                        {
                            Expires = DateTime.Now.AddYears(1),
                            Path = "/"
                        });
                    }
                }
            }
            catch
            {
                // Optional: Log error here
            }

            // ✅ Add filters in correct execution order
            filters.Add(new Filter(new LanguageSessionInitializer(), FilterScope.First, null));  // Must run first to initialize session
            filters.Add(new Filter(new LanguageFilter(), FilterScope.Global, null));
            filters.Add(new Filter(new LanguageLoaderFilter(), FilterScope.Global, null));
            //filters.Add(new Filter(new GlobalRequestFilter(), FilterScope.Global, null));
            filters.Add(new Filter(new VisitorTrackerAttribute(), FilterScope.Global, null));
            //filters.Add(new Filter(new LastUpdatedFilter(), FilterScope.Global, null));
            //filters.Add(new Filter(new BuildDateFilter(), FilterScope.Global, null));
            filters.Add(new Filter(new HandleErrorAttribute(), FilterScope.Global, null));

            return filters;
        }
    }
}
