﻿//using System;
//using System.Web;
//using System.Web.Mvc;

//namespace GIGWCompliantSite.ActionFilter
//{
//    public class LanguageSessionInitializer : ActionFilterAttribute
//    {
//        public override void OnActionExecuting(ActionExecutingContext filterContext)
//        {
//            var context = HttpContext.Current;

//            string sessionLang = context?.Session?["lang"]?.ToString()?.ToLower();
//            string cookieLang = context?.Request?.Cookies["lang"]?.Value?.ToLower();

//            string selectedLang = cookieLang ?? sessionLang;

//            if (string.IsNullOrEmpty(selectedLang))
//            {
//                selectedLang = "en"; // Default to English or use logic to detect browser language
//                context.Session["lang"] = selectedLang;

//                var langCookie = new HttpCookie("lang", selectedLang)
//                {
//                    Expires = DateTime.Now.AddYears(1),
//                    Path = "/"
//                };
//                context.Response.Cookies.Add(langCookie);
//            }
//            else
//            {
//                context.Session["lang"] = selectedLang;
//            }

//            base.OnActionExecuting(filterContext);
//        }
//    }
//}
using System;
using System.Web;
using System.Web.Mvc;

namespace GIGWCompliantSite.ActionFilter
{
    public class LanguageSessionInitializer : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            try
            {
                var session = HttpContext.Current.Session;
                var request = HttpContext.Current.Request;
                var response = HttpContext.Current.Response;

                if (session != null && session["lang"] == null)
                {
                    string cookieLang = request.Cookies["lang"]?.Value?.ToLower();
                    string lang = string.IsNullOrEmpty(cookieLang) ? "en" : cookieLang;

                    session["lang"] = lang;

                    if (string.IsNullOrEmpty(cookieLang))
                    {
                        var langCookie = new HttpCookie("lang", lang)
                        {
                            Expires = DateTime.Now.AddYears(1),
                            Path = "/"
                        };
                        response.Cookies.Add(langCookie);
                    }
                }
            }
            catch
            {
                // Optional: Log the error
            }

            base.OnActionExecuting(filterContext);
        }
    }
}
