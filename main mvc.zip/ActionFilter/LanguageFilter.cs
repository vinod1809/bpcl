﻿using System;
using System.IO;
using System.Web;
using System.Web.Mvc;

namespace GIGWCompliantSite.ActionFilter
{
    public class LanguageFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            try
            {
                var request = HttpContext.Current.Request;
                var session = HttpContext.Current.Session;

                string controller = filterContext.RouteData.Values["controller"]?.ToString();
                string action = filterContext.RouteData.Values["action"]?.ToString();

                LogDebug($"OnActionExecuting - Controller: {controller}, Action: {action}");

                if (string.IsNullOrEmpty(controller) || string.IsNullOrEmpty(action)) return;

                if (controller.Equals("Language", StringComparison.OrdinalIgnoreCase)) return;

                string lang = request.Cookies["lang"]?.Value?.ToLower()
                           ?? session["lang"]?.ToString()?.ToLower()
                           ?? "en";

                LogDebug($"Language detected: {lang}");

                if (lang != "hi") return;

                string viewPath = HttpContext.Current.Server.MapPath($"~/Views/{controller}/hi/{action}.cshtml");
                string sharedPath = HttpContext.Current.Server.MapPath($"~/Views/Shared/hi/{action}.cshtml");

                if (File.Exists(viewPath))
                {
                    filterContext.RouteData.DataTokens["HindiViewPath"] = $"~/Views/{controller}/hi/{action}.cshtml";
                    LogDebug($"Hindi view found in controller folder: {viewPath}");
                }
                else if (File.Exists(sharedPath))
                {
                    filterContext.RouteData.DataTokens["HindiViewPath"] = $"~/Views/Shared/hi/{action}.cshtml";
                    LogDebug($"Hindi view found in shared folder: {sharedPath}");
                }
                else
                {
                    LogDebug($"Hindi view NOT found for Controller: {controller}, Action: {action}");
                    session["lang"] = "en";
                    var cookie = new HttpCookie("lang", "en") { Expires = DateTime.Now.AddYears(1), Path = "/" };
                    HttpContext.Current.Response.Cookies.Add(cookie);

                    string returnUrl = request.RawUrl;
                    filterContext.Controller.TempData["ReturnUrl"] = returnUrl;

                    filterContext.Result = new RedirectToRouteResult(new System.Web.Routing.RouteValueDictionary
                    {
                        { "controller", "Language" },
                        { "action", "HindiNotAvailable" }
                    });

                    LogDebug($"Redirected to HindiNotAvailable with ReturnUrl: {returnUrl}");
                }
            }
            catch (Exception ex)
            {
                LogDebug($"Exception in OnActionExecuting: {ex.Message}");
            }

            base.OnActionExecuting(filterContext);
        }

        public override void OnResultExecuting(ResultExecutingContext filterContext)
        {
            try
            {
                if (filterContext.RouteData.DataTokens.ContainsKey("HindiViewPath"))
                {
                    string hindiViewPath = filterContext.RouteData.DataTokens["HindiViewPath"] as string;

                    var result = filterContext.Result as ViewResult;
                    if (result != null)
                    {
                        result.ViewName = hindiViewPath;  // Override existing view name
                        LogDebug($"OnResultExecuting - Forced rendering Hindi view (overridden): {hindiViewPath}");
                    }
                    else
                    {
                        // In case action returned something else
                        LogDebug("OnResultExecuting - Result is not ViewResult. Cannot force view.");
                    }
                }
                else
                {
                    LogDebug("OnResultExecuting - No HindiViewPath token found, rendering default view.");
                }
            }
            catch (Exception ex)
            {
                LogDebug($"Exception in OnResultExecuting: {ex.Message}");
            }

            base.OnResultExecuting(filterContext);
        }


        private void LogDebug(string message)
        {
            try
            {
                string logPath = HttpContext.Current.Server.MapPath("~/App_Data/LanguageFilterLog.txt");
                File.AppendAllText(logPath, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {message}{Environment.NewLine}");
            }
            catch
            {
                // Ignore logging errors
            }
        }
    }
}
