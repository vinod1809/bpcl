﻿using GIGWCompliantSite.Utilities;
using System.Web.Mvc;

namespace GIGWCompliantSite.ActionFilter
{
    public class VisitorTrackerAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            try
            {
                VisitorQueueManager.TrackVisitor();

                var stats = VisitorAggregator.GetAggregatedStats();

                filterContext.Controller.ViewBag.TotalVisitors = stats.Total;
                filterContext.Controller.ViewBag.CurrentDayVisitors = stats.CurrentDay;
                filterContext.Controller.ViewBag.DailyVisitors = stats.Daily;
            }
            catch
            {
                // Optional: Log error here (avoid exposing to end users)
                // LoggingService.LogError(ex);
            }

            base.OnActionExecuting(filterContext);
        }
    }
}
