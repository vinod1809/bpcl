﻿using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace GIGWCompliantSite.ActionFilter
{
    public class LanguageLoaderFilter : ActionFilterAttribute
    {
        public override void OnResultExecuted(ResultExecutedContext filterContext)
        {
            var response = filterContext.HttpContext.Response;

            if (response.ContentType == "text/html" && response.Filter != null)
            {
                response.Filter = new LanguageLoaderStream(response.Filter);
            }

            base.OnResultExecuted(filterContext);
        }

        private class LanguageLoaderStream : Stream


        {
            private readonly Stream _base;
            private readonly MemoryStream _cacheStream = new MemoryStream();

            public LanguageLoaderStream(Stream responseStream)
            {
                _base = responseStream;
            }

            public override void Write(byte[] buffer, int offset, int count)
            {
                _cacheStream.Write(buffer, offset, count);
            }

            public override void Flush()
            {
                _cacheStream.Position = 0;
                var reader = new StreamReader(_cacheStream, Encoding.UTF8);
                string html = reader.ReadToEnd();

                //                string loaderHtml = @"
                //<div id='langLoader' style='display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(255,255,255,0.8); z-index:9999; text-align:center; padding-top:20%;'>
                //    <img src='~/GIGW/assets/img/loader.gif' alt='Loading...' />
                //    <p id='langLoaderText'>Switching language...</p>
                //</div>";
                string loaderImageUrl = VirtualPathUtility.ToAbsolute("~/GIGW/assets/img/loader.gif");

                string loaderHtml = $@"
        <div id='langLoader' style='display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(255,255,255,0.8); z-index:9999; text-align:center; padding-top:20%;'>
        <img src='{loaderImageUrl}' alt='Loading...' style='width:80px; max-width:100%; height:auto;' />
        <p id='langLoaderText' style='font-size:18px; margin-top:12px; color:#333;'>Switching language...</p>
       </div>";

                if (html.Contains("</body>"))
                {
                    html = html.Replace("</body>", loaderHtml + "</body>");
                }

                var outputBuffer = Encoding.UTF8.GetBytes(html);
                _base.Write(outputBuffer, 0, outputBuffer.Length);
                _base.Flush();
            }

            public override bool CanRead => false;
            public override bool CanSeek => false;
            public override bool CanWrite => true;
            public override long Length => _base.Length;
            public override long Position { get => _base.Position; set => _base.Position = value; }
            public override void Close() => _base.Close();
            public override Task FlushAsync(System.Threading.CancellationToken cancellationToken)
                => _base.FlushAsync(cancellationToken);
            public override int Read(byte[] buffer, int offset, int count)
                => throw new NotSupportedException();
            public override long Seek(long offset, SeekOrigin origin)
                => throw new NotSupportedException();
            public override void SetLength(long value)
                => throw new NotSupportedException();
        }
    }
}
